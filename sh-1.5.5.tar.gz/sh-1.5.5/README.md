
> 此脚本来自阿里云（[这里](https://market.aliyun.com/products/56014009/cmgj000262.html?spm=5176.730005.0.0.CMza9G)），仅供学习 
> 
> 若需定制或其它需要，请联系原作者：qrj@jiagouyun.com

### 自动安装过程

此安装包可在阿里云所有linux系统上部署安装。

```
此安装包包含的软件及版本为：
nginx：1.4.4
apache：2.2.29、2.4.10
mysql：5.1.73、5.5.40、5.6.21
php：5.2.17、5.3.29、5.4.23、5.5.7
php扩展：memcache、Zend Engine/ OPcache
jdk：1.7.0
tomcat：7.0.54
ftp：（yum/apt-get安装）
phpwind：8.7 GBK
phpmyadmin：4.1.8
```

### 安装步骤

```
xshell/xftp上传sh目录

chmod –R 777 sh
cd sh
./install.sh

安装完成后请查看account.log文件，数据库密码在里面。
```
